# Typed of dogs > 2023-07-20 2:03pm
https://universe.roboflow.com/data-science-hrncf/typed-of-dogs

Provided by a Roboflow user
License: CC BY 4.0

